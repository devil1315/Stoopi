var userSettings = {
  Layout: "vertical",
  SidebarType: "full",
  BoxedLayout: true,
  Direction: "ltr",
  Theme: "light",
  ColorTheme: "Blue_Theme",
  cardBorder: false,
};

